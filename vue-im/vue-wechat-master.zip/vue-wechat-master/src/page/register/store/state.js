export default {
  nickname: '',
  password: '',
  account: ''
}