export default {
  // 用户信息
  userInfo: {

  },
  isOnLine: false,
  // 好友列表
  friendList: [],
  // 房间列表
  roomList: [],
  // 好友请求列表
  friendRequest: [],
  // 未读的好友请求
  unReadRequest: 0,
  // 临时房间列表 
  tempRoomList: [],


  tempRoomIdList: [],
  // 当前房间
  currRoom: {},
  currRoomIndex: 0,
  editForms: {
    avatar: '',
    signature: '',
    nickname: '',
    sex: 0,
    birthday: '',
    email: ''

  }
}