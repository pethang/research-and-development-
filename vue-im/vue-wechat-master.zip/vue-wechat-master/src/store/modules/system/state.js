export default {
  slideBarIsShow: false,
  weather: {}
}