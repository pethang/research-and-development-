<template lang="pug">
  
</template>
<script>
export default {
  name: 'search'
}
</script>

