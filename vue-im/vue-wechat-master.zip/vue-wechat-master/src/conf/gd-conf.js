export default {
  GD_KEY: '81fac366a6dcb6e8e5a49f6a07a0135b',
  GD_URL: 'https://restapi.amap.com/v3'
}