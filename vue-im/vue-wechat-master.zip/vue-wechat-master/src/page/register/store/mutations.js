export default {
  setField(state, {name, value}) {
    state[name] = value;
  }
}